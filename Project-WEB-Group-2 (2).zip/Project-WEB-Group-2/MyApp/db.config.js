module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "TripWallet4",
    DB: "tripwallet_db"
};